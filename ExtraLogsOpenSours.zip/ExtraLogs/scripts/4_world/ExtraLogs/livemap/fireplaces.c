modded class Fireplace
{
    ref _Event _registeredInstance;

    private void _InitGameLabs() { //create the map icon and track this item
        this._registeredInstance = new _Event("Fireplace", "campfire", this);

        if(GetGameLabs().IsServer()) {
            GetGameLabs().RegisterEvent(this._registeredInstance);
        } 
    }

    void ~Fireplace()
	{
        if(GetGameLabs().IsServer()) 
        {
            if(this._registeredInstance) GetGameLabs().RemoveEvent(this._registeredInstance);
        }
    }

    override void SetBurningState(bool is_burning)
	{
        super.SetBurningState(is_burning);
        if(m_LogConfig.LiveMap.ShowFirePlaces==1)
        {
            if(is_burning)
            {
                GetGame().GetCallQueue(CALL_CATEGORY_SYSTEM).Call(this._InitGameLabs);//Show Icon when Fireplace is active
            }
            else
            {
                GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(RemoveMapIcon, 300000, false); //Check to see if the fire stays out for 5 minutes
            }
        }
	}

    void RemoveMapIcon()//Remove icon if not burning after 5 minutes
    {
        if(!m_IsBurning && this._registeredInstance)
        {
            GetGameLabs().RemoveEvent(this._registeredInstance);
        }
        if(m_IsBurning)
        {   
            GetGame().GetCallQueue(CALL_CATEGORY_GAMEPLAY).CallLater(RemoveMapIcon, 300000, false); //Check to see if the fire stays out for 5 minutes
        }
    }
}