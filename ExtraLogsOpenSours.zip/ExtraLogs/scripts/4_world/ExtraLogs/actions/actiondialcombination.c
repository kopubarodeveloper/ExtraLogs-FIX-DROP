
modded class ActionDialCombinationLockOnTarget: ActionContinuousBase
{
    override void OnFinishProgressServer(ActionData action_data)
	{	
        super.OnFinishProgressServer(action_data);
        if(m_LogConfig.ServerConfig.ShowLockRaid==1){
        //add count to numbers click through
		ConstructionActionData constructionActionData = action_data.m_Player.GetConstructionActionData();
		CombinationLock combination_lock =  constructionActionData.GetCombinationLock();

        if(combination_lock.m_PlayerUnlocking != action_data.m_Player)
        {
            combination_lock.m_PlayerUnlocking = action_data.m_Player;
        }

        if(combination_lock.m_DialAttempts >= 50 && !combination_lock.m_CodeRaidAlarmFlagged)
        {
            combination_lock.m_CodeRaidAlarmFlagged = true;
            SendToCFTools(action_data.m_Player, "", string.Format("%1",combination_lock), "is code raiding ");
        }
        }
	}
}

modded class CombinationLock
{
    int m_DialAttempts;
    PlayerBase m_PlayerUnlocking;
    PlayerBase m_LockOwner;
    bool m_CodeRaidAlarmFlagged;
    bool m_CodeRaid_Idle_Reset_Started;

    override void SetInitialized()
	{
        super.SetInitialized();
        m_CodeRaid_Idle_Reset_Started = false;

    }


    void ResetDialAttempts() //Set attempts to zero
    {
        m_DialAttempts=0;
        m_CodeRaidAlarmFlagged = false;
        m_CodeRaid_Idle_Reset_Started = false;
        GetGame().GetCallQueue( CALL_CATEGORY_GAMEPLAY ).Remove(DialAttemptIdleReset) // Remove Idle check if unlocked
    }

    void AddDialAttempt()//Add 1 to attempt
    {
        m_DialAttempts++;
    }

    override void DialNextNumber()
	{
        super.DialNextNumber();
        //Print(string.Format("Owner: %1 Unlocker: %2",m_LockOwner,m_PlayerUnlocking));
        //if(m_LockOwner && (m_LockOwner == m_PlayerUnlocking)) return; // Skip logic if the owner is unlocking (Owner is the last person to attach the lock.)
        if(m_LogConfig.ServerConfig.ShowLockRaid==1){
            AddDialAttempt();

            if(!m_CodeRaid_Idle_Reset_Started)
            {
                GetGame().GetCallQueue( CALL_CATEGORY_GAMEPLAY ).CallLater( DialAttemptIdleReset, 300000, false ); // Reset attempt count in 5 minutes if raid flag not set
                m_CodeRaid_Idle_Reset_Started = true;
            }
        }
    }
    void DialAttemptIdleReset()
    {
        if(!m_CodeRaidAlarmFlagged)
        {
            m_DialAttempts=0;
            m_CodeRaid_Idle_Reset_Started = false;

        }
    }

    override void UnlockServer( EntityAI player, EntityAI parent )
	{
        super.UnlockServer(player,parent);
        ResetDialAttempts();// Reset logging for dial attempts
	}

}
