#ifdef bl_stove


modded class ActionDismantlePallet_bl
{
    override void OnFinishProgressServer( ActionData action_data ) 
	{
        super.OnFinishProgressServer(action_data);
        
        if(!action_data.m_Player || !action_data.m_Target) return;
        if(m_LogConfig.BoomlayThings.ShowDismantleActions==0) return;

        SendToCFTools(action_data.m_Player, "", string.Format("%1", action_data.m_Target.GetObject()), "Dismantled");
    }
}

modded class ActionDismantleStove_bl
{
    override void OnFinishProgressServer( ActionData action_data ) 
	{
        super.OnFinishProgressServer(action_data);
        
        if(!action_data.m_Player || !action_data.m_Target) return;
        if(m_LogConfig.BoomlayThings.ShowDismantleActions==0) return;

        SendToCFTools(action_data.m_Player, "", string.Format("%1", action_data.m_Target.GetObject()), "Dismantled");
    }
}

modded class ActionDismantleBed_bl
{
    override void OnFinishProgressServer( ActionData action_data ) 
	{
        super.OnFinishProgressServer(action_data);
        
        if(!action_data.m_Player || !action_data.m_Target) return;
        if(m_LogConfig.BoomlayThings.ShowDismantleActions==0) return;

        SendToCFTools(action_data.m_Player, "", string.Format("%1", action_data.m_Target.GetObject()), "Dismantled");
    }
}
#endif