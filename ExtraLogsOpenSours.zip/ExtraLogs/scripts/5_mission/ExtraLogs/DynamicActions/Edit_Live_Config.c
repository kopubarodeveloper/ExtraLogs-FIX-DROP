class ExtraLogs_SetVarible extends GameLabsContextAction {
    void ExtraLogs_SetVarible() {
        this.actionCode = "ExtraLogs_SetVarible";
        this.actionName = "ExtraLogs Toggle Log";
        this.actionIcon = "clipboard-list-check";
        this.actionColour = "danger";
        this.actionContext = "world";


        // Menu Boxes
        this.parameters.Insert("LogAction", GameLabsActionParameter("Log Name", "Name of Log you want to Toggle", "string"));
        this.parameters.Insert("LogStatus", GameLabsActionParameter("On/Off", "Set 1 for True or 0 for False", "int"));
    }

    override bool Execute(GameLabsActionContext context) {

        

        return true;
    }
};