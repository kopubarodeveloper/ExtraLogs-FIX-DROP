class ExtraLogs_Testing extends GameLabsContextAction {
    void ExtraLogs_Testing() {
        this.actionCode = "ExtraLogs_Testing";
        this.actionName = "ExtraLogs Explode player";
        this.actionIcon = "biohazard";
        this.actionColour = "danger";
        this.actionContext = "player";
    }

    override bool Execute(GameLabsActionContext context) {
        PlayerBase player;
        PlayerBase.CastTo(player, context.GetReferencedObject());

        GetGameLabs().GetLogger().Warn(string.Format("[Player-Explode] %1", player));
        player.Explode(DT_EXPLOSION, "LandFuelFeed_Ammo");
        return true;
    }
};